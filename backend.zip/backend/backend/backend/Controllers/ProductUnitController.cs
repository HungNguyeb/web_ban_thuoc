﻿using Microsoft.AspNetCore.Mvc;
using backend.Models;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class ProductUnitController : ControllerBase
{
    private readonly FinalContext db;
    public ProductUnitController(FinalContext context) { db = context; }

    [HttpGet]
    public IActionResult GetAll() => Ok(db.ProductUnits.Include(x => x.Product).ToList());

    [HttpGet("{id}")]
    public IActionResult GetById(Guid id) =>
        Ok(db.ProductUnits.Include(x => x.Product).FirstOrDefault(p => p.Id == id));

    [HttpPost]
    public IActionResult Create([FromBody] ProductUnit pu)
    {
        pu.Id = Guid.NewGuid();
        db.ProductUnits.Add(pu);
        db.SaveChanges();
        return Ok(pu);
    }

    [HttpPut("{id}")]
    public IActionResult Update(Guid id, [FromBody] ProductUnit pu)
    {
        var existing = db.ProductUnits.Find(id);
        if (existing == null) return NotFound();
        existing.ProductId = pu.ProductId;
        existing.Name = pu.Name;
        existing.Quantity = pu.Quantity;
        existing.Price = pu.Price;
        db.SaveChanges();
        return Ok(existing);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(Guid id)
    {
        var item = db.ProductUnits.Find(id);
        if (item == null) return NotFound();
        db.ProductUnits.Remove(item);
        db.SaveChanges();
        return Ok();
    }
    [HttpGet("byProduct/{productId}")]
    public IActionResult GetByProductId(Guid productId)
    {
        var units = db.ProductUnits.Where(u => u.ProductId == productId).ToList();
        return Ok(units);
    }
}
