﻿using Microsoft.AspNetCore.Mvc;
using backend.Models;
using System;
using System.Linq;

[ApiController]
[Route("api/[controller]")]
public class PromotionController : ControllerBase
{
    private readonly FinalContext db;
    public PromotionController(FinalContext context) { db = context; }

    [HttpGet]
    public IActionResult GetAll() => Ok(db.Promotions.ToList());

    [HttpGet("{id}")]
    public IActionResult GetById(Guid id)
    {
        var promo = db.Promotions.FirstOrDefault(p => p.Id == id);
        if (promo == null) return NotFound();
        return Ok(promo);
    }

    [HttpPost]
    public IActionResult Create([FromBody] Promotion promotion)
    {
        promotion.Id = Guid.NewGuid();
        db.Promotions.Add(promotion);
        db.SaveChanges();
        return Ok(promotion);
    }

    [HttpPut("{id}")]
    public IActionResult Update(Guid id, [FromBody] Promotion promotion)
    {
        var existing = db.Promotions.Find(id);
        if (existing == null) return NotFound();
        existing.Name = promotion.Name;
        existing.Description = promotion.Description;
        existing.DiscountPercent = promotion.DiscountPercent;
        existing.DiscountAmount = promotion.DiscountAmount;
        existing.StartDate = promotion.StartDate;
        existing.EndDate = promotion.EndDate;
        existing.Code = promotion.Code;
        existing.IsActive = promotion.IsActive;
        db.SaveChanges();
        return Ok(existing);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(Guid id)
    {
        var item = db.Promotions.Find(id);
        if (item == null) return NotFound();
        db.Promotions.Remove(item);
        db.SaveChanges();
        return Ok();
    }

    // === BỔ SUNG API TÌM KHUYẾN MÃI THEO CODE ===
    [HttpGet("check")]
    public IActionResult CheckPromotionByCode([FromQuery] string productCode)
    {
        if (string.IsNullOrWhiteSpace(productCode))
            return BadRequest(new { message = "Thiếu mã khuyến mãi!" });

        var now = DateTime.Now;
        var codeLower = productCode.ToLower();

        var promo = db.Promotions
            .FirstOrDefault(p =>
                p.Code != null &&
                p.Code.ToLower() == codeLower &&
                (p.IsActive == true) &&
                (p.StartDate == null || p.StartDate <= now) &&
                (p.EndDate == null || p.EndDate >= now)
            );

        if (promo == null)
            return Ok(new { hasPromotion = false });

        return Ok(new
        {
            hasPromotion = true,
            promotionId = promo.Id,
            promotionName = promo.Name,
            discountPercent = promo.DiscountPercent,
            discountAmount = promo.DiscountAmount,
            startDate = promo.StartDate,
            endDate = promo.EndDate,
            code = promo.Code
        });
    }

}
