﻿using Microsoft.AspNetCore.Mvc;
using backend.Models;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class ProductPromotionController : ControllerBase
{
    private readonly FinalContext db;
    public ProductPromotionController(FinalContext context) { db = context; }

    [HttpGet]
    public IActionResult GetAll() => Ok(db.ProductPromotions
        .Include(pp => pp.Product)
        .Include(pp => pp.Promotion)
        .ToList());

    [HttpGet("{id}")]
    public IActionResult GetById(Guid id) =>
        Ok(db.ProductPromotions
            .Include(pp => pp.Product)
            .Include(pp => pp.Promotion)
            .FirstOrDefault(pp => pp.Id == id));

    [HttpPost]
    public IActionResult Create([FromBody] ProductPromotion pp)
    {
        pp.Id = Guid.NewGuid();
        db.ProductPromotions.Add(pp);
        db.SaveChanges();
        return Ok(pp);
    }

    [HttpPut("{id}")]
    public IActionResult Update(Guid id, [FromBody] ProductPromotion pp)
    {
        var existing = db.ProductPromotions.Find(id);
        if (existing == null) return NotFound();
        existing.ProductId = pp.ProductId;
        existing.PromotionId = pp.PromotionId;
        db.SaveChanges();
        return Ok(existing);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(Guid id)
    {
        var item = db.ProductPromotions.Find(id);
        if (item == null) return NotFound();
        db.ProductPromotions.Remove(item);
        db.SaveChanges();
        return Ok();
    }
}
