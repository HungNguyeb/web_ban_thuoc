﻿using backend.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema; // thêm using này ở đầu file

public class ProductPromotion
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    [Column("product_id")] // Đúng tên cột SQL Server
    public Guid ProductId { get; set; }

    [Required]
    [Column("promotion_id")]
    public Guid PromotionId { get; set; }

    public virtual Product Product { get; set; }
    public virtual Promotion Promotion { get; set; }
}
